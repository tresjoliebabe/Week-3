//
//  TwitterClient.swift
//  TwitterDemo
//
//  Created by NicoleA on 4/16/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit
import BDBOAuth1Manager

class TwitterClient: BDBOAuth1SessionManager {
    
    static let sharedInstance = TwitterClient(baseURL: URL(string: "https://api.twitter.com")! as URL!, consumerKey: "kui3DZKJEAwyCQzCCVnUvwPDd", consumerSecret: "AVKPxcyTXUjyprcpkPKCmqUgVQ5sCs8zpHWeH0X8pREGBpRsAm")
    
    var loginSuccess: (() -> ())?
    var loginFailure: ((Error) -> ())?
    
    //declaring closure types
    func login(success: @escaping ()->(), failure: @escaping (Error)->()) {
        
        var loginSuccess = success
        var loginFailure = failure
        
        //clear -- logout first
        TwitterClient.sharedInstance?.deauthorize()
        
        //Must get a request token from Twitter so that user can confirm their identity
        TwitterClient.sharedInstance?.fetchRequestToken(withPath: "oauth/request_token", method: "GET", callbackURL: URL(string: "twitterdemo://oauth") as URL!, scope: nil, success: {(requestToken: BDBOAuth1Credential?) -> Void in print("got a token")
            //switches out of application to something else like a website e.g. mobile safari
            //need to include oauth_token to be identified
            let requestTokenString = (requestToken?.token)! as String
            let url = URL(string: "https://api.twitter.com/oauth/authorize?oauth_token=\(requestTokenString)")
            UIApplication.shared.open(url!)
        })  {(error: Error?) -> Void in
            print("error: \(error?.localizedDescription)")
            self.loginFailure?(error!)
        }
    }
    
    func handleOpenUrl(url: URL){
        let requestToken = BDBOAuth1Credential(queryString: url.query)
        TwitterClient.sharedInstance?.fetchAccessToken(withPath: "oauth/access_token", method: "POST", requestToken: requestToken, success: { (accessToken: BDBOAuth1Credential?) -> Void in
            //print("I got the access token")
            self.loginSuccess?()
            
        }) { (error: Error?) -> Void in
            print("error: \(error?.localizedDescription)")
            self.loginFailure?(error!)
        }

    }
    
    
    //function must take a closure
    //() no response
    func homeTimeline(success: @escaping ([Tweet]) ->(), failure: @escaping (Error) ->()){
        
        get("1.1/statuses/home_timeline.json", parameters: nil, progress: nil, success: { (task: URLSessionDataTask, response: Any?) -> Void in
            //let tweets = response as! [NSDictionary]
            let dictionaries = response as! [NSDictionary]
            
            let tweets = Tweet.tweetsWithArray(dictionaries: dictionaries)
            
                /*for tweet in tweets{
                    print("\(tweet.text!)")
                }*/
            success(tweets)
            
            }, failure: { (task: URLSessionDataTask?, error: Error?) -> Void in
                failure (error!)
        })
    }//ht

    func currentAccount(){
         get("1.1/account/verify_credentials.json", parameters: nil, progress: nil, success: { (task: URLSessionDataTask?, response: Any?) -> Void in
            let userDictionary=response as! NSDictionary
            
            let user = User(dictionary: userDictionary)
            print("name: \(user.name)")
            print("screenname: \(user.screenname)")
            print("profile url: \(user.profileUrl)")
            print("description: \(user.tagLine)")
            
            }, failure: { (task: URLSessionDataTask?, error: Error?) -> Void in
        })
    }//ca
    
    
    
}//class
