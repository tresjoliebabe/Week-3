//
//  User.swift
//  TwitterDemo
//
//  Created by NicoleA on 4/15/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit

class User: NSObject {
    
    //models for capturing types (not logic)
    //also does saving to disk
    var name: String?
    var screenname: String?
    var profileUrl: URL?
    var tagLine: String?
    
    init(dictionary: NSDictionary){
        name = dictionary["name"] as? String
        screenname = dictionary["screen_name"] as? String
        tagLine = dictionary["description"] as? String
        let profileUrlString = dictionary["profile_image_url_https"] as? String
        if let profileUrlString = profileUrlString {
            profileUrl = URL(string: profileUrlString)
        }
    }
}
