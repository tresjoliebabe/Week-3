//
//  TweetCell.swift
//  TwitterDemo
//
//  Created by NicoleA on 4/17/17.
//  Copyright © 2017 Agetas. All rights reserved.
//

import UIKit



class TweetCell: UITableViewCell {

    
    @IBOutlet weak var tweetLabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
